#ifndef DIALOG_PORT_H
#define DIALOG_PORT_H

#include <QDialog>

#include "QSerialPort"

namespace Ui {
class Dialog_Port;
}

class Dialog_Port : public QDialog
{
    Q_OBJECT

public:
    struct Settings {
        QString name;
        qint32 baudRate;
        QString stringBaudRate;
        QSerialPort::DataBits dataBits;
        QString stringDataBits;
        QSerialPort::Parity parity;
        QString stringParity;
        QSerialPort::StopBits stopBits;
        QString stringStopBits;
        QSerialPort::FlowControl flowControl;
        QString stringFlowControl;
        bool localEchoEnabled;
    };

    Settings settings() const;

public:
    explicit Dialog_Port(QWidget *parent = nullptr);
    ~Dialog_Port();

    void fillPortsParameters();
    void fillPortsInfo();
    void showPortInfo(int idx);
    void updateSettings();
    void apply();

private:
    Ui::Dialog_Port *ui;
    Settings m_currentSettings;
};

#endif // DIALOG_PORT_H
