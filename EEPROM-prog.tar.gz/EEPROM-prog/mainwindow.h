#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "QSerialPort"
#include "QLabel"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class Dialog_Port;
class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void initActionsConnections();
    void test_message();
    void readData();
    int hue2rgb(int p, int q, int t);


private slots:
    void on_actionSelectPort_triggered();

    void openSerialPort();
    void closeSerialPort();
    void on_actionConnect_triggered();
    void on_actionDisConnect_triggered();

    void on_but_read_clicked();

    void on_actionquit_triggered();

    void on_but_save_clicked();

    void on_but_load_clicked();

    void on_but_erase_clicked();

    void on_but_write_clicked();

    void on_actionAbout_triggered();

private:
//    void initActionsConnections();

private:
    Ui::MainWindow *ui;

private:
    void showStatusMessage(const QString &message);

    Dialog_Port *m_settings = nullptr;
    QSerialPort *m_serial = nullptr;
    QLabel *m_status = nullptr;
};
#endif // MAINWINDOW_H
