#include "dialog_port.h"
#include "ui_dialog_port.h"

#include "QSerialPortInfo"
#include "QSerialPort"

#include "QDebug"
#include "QPushButton"


static const char blankString[] = QT_TRANSLATE_NOOP("SettingsDialog", "N/A");

Dialog_Port::Dialog_Port(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_Port)
{
    ui->setupUi(this);


    connect(ui->button_apply, &QPushButton::clicked,
                this, &Dialog_Port::apply);
    connect(ui->dialog_port, QOverload<int>::of(&QComboBox::currentIndexChanged),
                this, &Dialog_Port::showPortInfo);

    fillPortsParameters();
    fillPortsInfo();
}

Dialog_Port::~Dialog_Port()
{
    delete ui;
}

void Dialog_Port::apply()
{
    updateSettings();
    hide();
}

Dialog_Port::Settings Dialog_Port::settings() const
{
    return m_currentSettings;
}

void Dialog_Port::updateSettings()
{
    m_currentSettings.name = ui->dialog_port->currentText();

    if (ui->dialog_baud->currentIndex() == 4) {
        m_currentSettings.baudRate = ui->dialog_baud->currentText().toInt();
    } else {
        m_currentSettings.baudRate = static_cast<QSerialPort::BaudRate>(
                    ui->dialog_baud->itemData(ui->dialog_baud->currentIndex()).toInt());
    }
    m_currentSettings.stringBaudRate = QString::number(m_currentSettings.baudRate);

    m_currentSettings.dataBits = static_cast<QSerialPort::DataBits>(
                ui->dialog_data_bits->itemData(ui->dialog_data_bits->currentIndex()).toInt());
    m_currentSettings.stringDataBits = ui->dialog_data_bits->currentText();

    m_currentSettings.parity = static_cast<QSerialPort::Parity>(
                ui->dialog_parity->itemData(ui->dialog_parity->currentIndex()).toInt());
    m_currentSettings.stringParity = ui->dialog_parity->currentText();

    m_currentSettings.stopBits = static_cast<QSerialPort::StopBits>(
                ui->dialog_stop->itemData(ui->dialog_stop->currentIndex()).toInt());
    m_currentSettings.stringStopBits = ui->dialog_stop->currentText();

    m_currentSettings.flowControl = static_cast<QSerialPort::FlowControl>(
                ui->dialog_flow->itemData(ui->dialog_flow->currentIndex()).toInt());
    m_currentSettings.stringFlowControl = ui->dialog_flow->currentText();

//    m_currentSettings.localEchoEnabled = ui->di->isChecked();
}

void Dialog_Port::showPortInfo(int idx)
{
    if (idx == -1)
        return;

    const QStringList list = ui->dialog_port->itemData(idx).toStringList();
    ui->dialog_description->setText(tr("Description: %1").arg(list.count() > 1 ? list.at(1) : tr(blankString)));
    ui->dialog_manufactured->setText(tr("Manufacturer: %1").arg(list.count() > 2 ? list.at(2) : tr(blankString)));
    ui->dialog_serial->setText(tr("Serial number: %1").arg(list.count() > 3 ? list.at(3) : tr(blankString)));
    ui->dialog_location->setText(tr("Location: %1").arg(list.count() > 4 ? list.at(4) : tr(blankString)));
    ui->dialog_vendor->setText(tr("Vendor Identifier: %1").arg(list.count() > 5 ? list.at(5) : tr(blankString)));
    ui->dialog_product->setText(tr("Product Identifier: %1").arg(list.count() > 6 ? list.at(6) : tr(blankString)));
}


void Dialog_Port::fillPortsParameters()
{

    ui->dialog_baud->addItem(QStringLiteral("9600"), QSerialPort::Baud9600);
    ui->dialog_baud->addItem(QStringLiteral("19200"), QSerialPort::Baud19200);
    ui->dialog_baud->addItem(QStringLiteral("38400"), QSerialPort::Baud38400);
    ui->dialog_baud->addItem(QStringLiteral("115200"), QSerialPort::Baud115200);
    ui->dialog_baud->addItem(tr("Custom"));

    ui->dialog_data_bits->addItem(QStringLiteral("5"), QSerialPort::Data5);
    ui->dialog_data_bits->addItem(QStringLiteral("6"), QSerialPort::Data6);
    ui->dialog_data_bits->addItem(QStringLiteral("7"), QSerialPort::Data7);
    ui->dialog_data_bits->addItem(QStringLiteral("8"), QSerialPort::Data8);
    ui->dialog_data_bits->setCurrentIndex(3);

    ui->dialog_parity->addItem(tr("None"), QSerialPort::NoParity);
    ui->dialog_parity->addItem(tr("Even"), QSerialPort::EvenParity);
    ui->dialog_parity->addItem(tr("Odd"), QSerialPort::OddParity);
    ui->dialog_parity->addItem(tr("Mark"), QSerialPort::MarkParity);
    ui->dialog_parity->addItem(tr("Space"), QSerialPort::SpaceParity);

    ui->dialog_stop->addItem(QStringLiteral("1"), QSerialPort::OneStop);
    ui->dialog_stop->addItem(QStringLiteral("2"), QSerialPort::TwoStop);

    ui->dialog_flow->addItem(tr("None"), QSerialPort::NoFlowControl);
    ui->dialog_flow->addItem(tr("RTS/CTS"), QSerialPort::HardwareControl);
    ui->dialog_flow->addItem(tr("XON/XOFF"), QSerialPort::SoftwareControl);
}

void Dialog_Port::fillPortsInfo()
{
    ui->dialog_port->clear();
    QString description;
    QString manufacturer;
    QString serialNumber;
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos) {
        QStringList list;
        description = info.description();
        manufacturer = info.manufacturer();
        serialNumber = info.serialNumber();
        list << info.portName()
             << (!description.isEmpty() ? description : blankString)
             << (!manufacturer.isEmpty() ? manufacturer : blankString)
             << (!serialNumber.isEmpty() ? serialNumber : blankString)
             << info.systemLocation()
             << (info.vendorIdentifier() ? QString::number(info.vendorIdentifier(), 16) : blankString)
             << (info.productIdentifier() ? QString::number(info.productIdentifier(), 16) : blankString);

        ui->dialog_port->addItem(list.first(), list);
    }

    ui->dialog_port->addItem(tr("Custom"));
}
