#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "QLabel"
#include "QMessageBox"

#include "dialog_port.h"
#include "QDebug"

#include "iostream"
#include "string.h"
#include "stdio.h"

#include "QFile"
#include "QFileDialog"

//char buff[1024];

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_settings(new Dialog_Port)
    , m_serial(new QSerialPort(this))
    , m_status(new QLabel)

{
//    ui->statusbar->addWidget(m_status);
//    qDebug() << m_status;

//    initActionsConnections();

    ui->setupUi(this);

    for(int x=0; x < 4; x++) {
        for(int y=0; y < 16; y++)
        {
            ui->dump->setItem(x,y,new QTableWidgetItem("Empty."));
        }
    }

    connect(m_serial, &QSerialPort::readyRead, this, &MainWindow::readData); // обработка поступающих данных с порта
}

MainWindow::~MainWindow()
{
    delete ui;
}

// читаем порт
void MainWindow::readData()
{
    char buff[1024];
    QByteArray m_data = m_serial->readAll();
//    const QByteArray m_data = m_serial->readAll();

        strcat(buff, m_data);

            if(strstr(buff, "stop")) {
                QString str=buff;
                QStringList strList=str.split(";");

                for(int x=0; x < 4; x++) {
                    for(int y=0; y < 16; y++)
                    {
                        ui->dump->setItem(x,y,new QTableWidgetItem(strList.at(x*16 + y)));
                    }
                }
            }
}


void MainWindow::openSerialPort()
{
    qDebug() << "openSerialPort";
    const Dialog_Port::Settings p = m_settings->settings();
    m_serial->setPortName(p.name);
    m_serial->setBaudRate(p.baudRate);
    m_serial->setDataBits(p.dataBits);
    m_serial->setParity(p.parity);
    m_serial->setStopBits(p.stopBits);
    m_serial->setFlowControl(p.flowControl);
    if (m_serial->open(QIODevice::ReadWrite)) {
        ui->actionConnect->setEnabled(false);
        ui->actionDisConnect->setEnabled(true);
        ui->actionSelectPort->setEnabled(false);

        showStatusMessage(tr("Connected to %1 : %2, %3, %4, %5, %6")
                          .arg(p.name).arg(p.stringBaudRate).arg(p.stringDataBits)
                          .arg(p.stringParity).arg(p.stringStopBits).arg(p.stringFlowControl));
    } else {
        QMessageBox::critical(this, tr("Error"), m_serial->errorString());

        showStatusMessage(tr("Open error"));
    }

}


void MainWindow::showStatusMessage(const QString &message)
{
    m_status->setText(message);
    ui->statusbar->showMessage(message);
}


void MainWindow::closeSerialPort()
{
    if (m_serial->isOpen())
        m_serial->close();

    ui->actionConnect->setEnabled(true);
    ui->actionDisConnect->setEnabled(false);
    ui->actionSelectPort->setEnabled(true);
    showStatusMessage(tr("Disconnected"));
}

void MainWindow::initActionsConnections()
{

}

void MainWindow::on_actionSelectPort_triggered()
{
    m_settings->show();
}

void MainWindow::test_message()
{
    qDebug() << "test message";
}

void MainWindow::on_actionConnect_triggered()
{
    openSerialPort();
}

void MainWindow::on_actionDisConnect_triggered()
{
    closeSerialPort();
}

void MainWindow::on_but_read_clicked()
{
    //начать чтение
    if(m_serial->isOpen()) {
        m_serial->write("r"); //
        m_serial->flush();
        m_serial->waitForBytesWritten(10); // ждем пока дойдет
    }
    else
    {
        QMessageBox::information(this, "Сообщение", "Нет подключения к порту.");
    }
}

void MainWindow::on_actionquit_triggered()
{
    closeSerialPort();
    QCoreApplication::quit();
//    QApplication::quit();
}

void MainWindow::on_but_save_clicked()
{
    char mask[4];
    char data[4];

    QString str=data;

    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("сохранить HEX файл"),
                                                    "",
                                                    tr("*.hex(*.hex);;All files (*)"),
                                                    nullptr,
                                                    QFileDialog::DontUseNativeDialog);
    if(fileName.isEmpty())
        return;
    else
    {
        QFile file(fileName);
        if(!file.open(QIODevice::WriteOnly)) {
            QMessageBox::information(this, tr("Невозможно открыть файл"),
                                     file.errorString());
            return;
        }

        // вытягиваем и запихиваем в файл
        for(int x=0; x < 4; x++) {
            for(int y=0; y < 16; y++)
            {
                str.clear();

                if(ui->dump->item(x,y)->text().size() < 4) {
                    int size = ui->dump->item(x,y)->text().size();
                    switch (size) {
                    case 1:
                        strcpy(mask,"000");
                        break;
                    case 2:
                        strcpy(mask,"00");
                        break;
                    case 3:
                        strcpy(mask,"0");
                        break;
                    default:
                        break;
                    }
                    // добавляем вперед "0"
                    str = mask + ui->dump->item(x,y)->text();
                }
                else
                {
                    // выводим без изменений
                    str = ui->dump->item(x,y)->text();
                }
                file.write(str.toLatin1());
                file.write(" ");
            }
            file.write("\n");
        }
        file.close();
    }
}

void MainWindow::on_but_load_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("файл для загрузки (только *.hex)"),
                                                    "",
                                                    tr("*.hex(*.hex);;All files (*)"),
                                                    nullptr,
                                                    QFileDialog::DontUseNativeDialog);
    if(fileName.isEmpty())
        return;
    else
    {
        QFile file(fileName);
        if(!file.open(QIODevice::ReadOnly)) {
            QMessageBox::information(this, tr("Невозможно открыть файл"),
                                     file.errorString());
            return;
        }
        QByteArray d_read =  file.readAll();
        file.close();

        QString str=d_read;
        QStringList strList=str.split(" ");

        strList.replaceInStrings("\n","");

        for(int x=0; x < 4; x++) {
            for(int y=0; y < 16; y++)
            {
                ui->dump->setItem(x,y,new QTableWidgetItem(strList.at(x*16 + y)));
            }
        }
    }
}

void MainWindow::on_but_erase_clicked()
{
    //начать чтение
    if(m_serial->isOpen()) {
        m_serial->write("e"); //
        m_serial->flush();
        m_serial->waitForBytesWritten(10); // ждем пока дойдет

        QMessageBox::information(this, "Сообщение", "Память очищена.");
    }
    else
    {
        QMessageBox::information(this, "Сообщение", "Нет подключения к порту.");
    }
}

void MainWindow::on_but_write_clicked()
{
    QString send = "w ";
    QString fin = "*";

    QMessageBox msgBox;

    // вытягиваем и запихиваем в файл
    for(int x=0; x < 4; x++) {
        for(int y=0; y < 16; y++)
        {
            QString quant = ui->dump->item(x,y)->text();
            send = send + quant + fin;

            if(m_serial->isOpen()) {
                m_serial->write(send.toLatin1()); //
                m_serial->flush();
                m_serial->waitForBytesWritten(10); // ждем пока дойдет
            }
            else
            {
                msgBox.setText("Внимательние!\nНет подключения к порту.");
                msgBox.setInformativeText("Ок - завершить.");
                msgBox.setStandardButtons(QMessageBox::Ok);
                msgBox.setIcon(QMessageBox::Information);
                msgBox.setDefaultButton(QMessageBox::Ok);
                int res = msgBox.exec();
                if (res == QMessageBox::Ok)     // нажата кнопка Ok
                    QCoreApplication::quit();   // завершить работу
            }
            send.clear();
            send.append("w ");
        }
    }
    QMessageBox::information(this, "Сообщение", "Память записана.");

}

void MainWindow::on_actionAbout_triggered()
{
    QMessageBox::information(this, "Сообщение", "Читать, писать, сохранять EEPROM AT93C46D \n(16x64)");

}
