#include "mainwindow.h"

#include <QApplication>

#include "QDebug"
#include "QStyleFactory"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QApplication::setStyle("Fusion");

    QPalette darkPalette;

    darkPalette.setColor(QPalette::Window, QColor(50, 50, 50));
    darkPalette.setColor(QPalette::WindowText, Qt::white);
    darkPalette.setColor(QPalette::Base, QColor(100, 100, 100));
    darkPalette.setColor(QPalette::AlternateBase, QColor(53, 53, 53));
    darkPalette.setColor(QPalette::ToolTipBase, Qt::white);
    darkPalette.setColor(QPalette::ToolTipText, Qt::white);
    darkPalette.setColor(QPalette::Text, QColor(200, 200, 200));
    darkPalette.setColor(QPalette::Button, QColor(80, 80, 80));
    darkPalette.setColor(QPalette::ButtonText, Qt::white);
    darkPalette.setColor(QPalette::BrightText, Qt::red);
    darkPalette.setColor(QPalette::Link, QColor(42, 130, 218));
    darkPalette.setColor(QPalette::Highlight, QColor(247, 147, 30));
    darkPalette.setColor(QPalette::HighlightedText, Qt::black);

// Install this palette
    qApp->setPalette(darkPalette);

    MainWindow w;
    w.show();
    return a.exec();
}
